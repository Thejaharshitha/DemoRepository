# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 12:08:15 2019

@author: 427516
"""


import pandas as pd
import numpy as np

import matplotlib.pyplot as plt

# to show all the columns of the dataframe in the notebook
pd.set_option('display.max_columns', None)

data = pd.read_csv('./data/houseprice/houseprice.csv')
data.shape
# let's visualise the dataset
data.head()

# find the variables with missing observations
vars_with_na = [var for var in data.columns if data[var].isnull().mean() > 0]
vars_with_na


# let's find out whether they are numerical or categorical
data[vars_with_na].dtypes


# let's have a look at the values of the variables with
# missing data
data[vars_with_na].head(10)


# let's find out the percentage of observations missing per variable

# calculate the percentage of missing (as we did in section 3)
# using the isnull() and mean() methods from pandas
data_na = data[vars_with_na].isnull().mean()

# transform the array into a dataframe
data_na = pd.DataFrame(data_na.reset_index())

# add column names to the dataframe
data_na.columns = ['variable', 'na_percentage']

# order the dataframe according to percentage of na per variable
data_na.sort_values(by='na_percentage', ascending=False, inplace=True)

# show
data_na



# capture variables with no or less than 5% NA
vars_cca = [var for var in data.columns if data[var].isnull().mean() < 0.05]
vars_cca


# calculate percentage of observations with complete
# cases: i.e., with values for all the variables

# the method dropna(), discards the observations that contain
# na in any of the rows / columns

len(data[vars_cca].dropna()) / len(data)


# create the complete case dataset
# in other words, remove observations with na in any variable
data_cca = data[vars_cca].dropna()
data.shape, data_cca.shape



# plot the histograms for all numerival variables in the complete
# case dataset (as we did in section 3)

data_cca.hist(bins=50, density=True, figsize=(12, 12))
plt.show()



## let's check the distribution of a few variables before and after 
# cca: histogram

fig = plt.figure()
ax = fig.add_subplot(111)

# original data
data['GrLivArea'].hist(bins=50, ax=ax, density=True, color='red')

# data after cca, the argument alpha makes the color transparent, so we can
# see the overlay of the 2 distributions
data_cca['GrLivArea'].hist(bins=50, ax=ax, color='blue', density=True, alpha=0.8)


## let's check the distribution of a few variables before and after 
# cca: density plot
fig = plt.figure()
ax = fig.add_subplot(111)
# original data
data['GrLivArea'].plot.density(color='red')
# data after cca
data_cca['GrLivArea'].plot.density(color='blue')


## let's check the distribution of a few variables before and after 
# cca: histogram
fig = plt.figure()
ax = fig.add_subplot(111)
# original data
data['BsmtFinSF1'].hist(bins=50, ax=ax, density=True, color='red')
# data after cca, the argument alpha makes the color transparent, so we can
# see the overlay of the 2 distributions
data_cca['BsmtFinSF1'].hist(bins=50, ax=ax, color='blue', density=True, alpha=0.8)



## let's check the distribution of a few variables before and after 
# cca: density plot
fig = plt.figure()
ax = fig.add_subplot(111)
# original data
data['BsmtFinSF1'].plot.density(color='red')
# data after cca
data_cca['BsmtFinSF1'].plot.density(color='blue')



# the following function captures the percentage of observations
# for each category in the original and complete case dataset
# and puts them together in a new dataframe
def categorical_distribution(df, df_cca, variable):
    tmp = pd.concat(
        [
            # percentage of observations per category, original data
            df[variable].value_counts() / len(df),

            # percentage of observations per category, cca data
            df_cca[variable].value_counts() / len(df_cca)
        ],
        axis=1)
    # add column names
    tmp.columns = ['original', 'cca']
    return tmp


# run the function in a categorical variable
categorical_distribution(data, data_cca, 'BsmtQual')



categorical_distribution(data, data_cca, 'MasVnrType')



categorical_distribution(data, data_cca, 'SaleCondition')


