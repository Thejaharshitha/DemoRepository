# -*- coding: utf-8 -*-
"""
Created on Tue Nov 26 20:03:13 2019

@author: 427516
"""

from math import sqrt
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# for the model
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Lasso
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_squared_error, r2_score

# for feature engineering
from sklearn.preprocessing import StandardScaler
from feature_engine import missing_data_imputers as mdi
from feature_engine import discretisers as dsc
from feature_engine import categorical_encoders as ce


import seaborn as sns
color = sns.color_palette()
sns.set_style('darkgrid')

pd.pandas.set_option('display.max_columns', None)

# load dataset
data = pd.read_csv('input/houseprice.csv')
print(data.shape)
data.head()


# let's inspect the type of variables in pandas
data.dtypes


# we have an Id variable, that we should not use for predictions:
print('Number of House Id labels: ', len(data.Id.unique()))
print('Number of Houses in the Dataset: ', len(data))

# find categorical variables
categorical = [var for var in data.columns if data[var].dtype=='O']
print('There are {} categorical variables'.format(len(categorical)))


# make a list of the numerical variables first
numerical = [var for var in data.columns if data[var].dtype!='O']

# list of variables that contain year information
year_vars = [var for var in numerical if 'Yr' in var or 'Year' in var]

year_vars

# plot median house price per month in which it was sold
data.groupby('MoSold')['SalePrice'].median().plot()
plt.title('House price variation along the year')
plt.ylabel('median House price')

# let's visualise the values of the discrete variables
discrete = []
for var in numerical:
    if len(data[var].unique()) < 20 and var not in year_vars:
        print(var, ' values: ', data[var].unique())
        discrete.append(var)
print()
print('There are {} discrete variables'.format(len(discrete)))


# find continuous variables
# let's remember to skip the Id variable and the target variable SalePrice
# which are both also numerical
numerical = [var for var in numerical if var not in discrete and var not in [
    'Id', 'SalePrice'] and var not in year_vars]
print('There are {} numerical and continuous variables'.format(len(numerical)))


# let's output variables with NA and the percentage of NA
for var in data.columns:
    if data[var].isnull().sum() > 0:
        print(var, data[var].isnull().mean())




fig, ax = plt.subplots()
ax.scatter(x = data['GrLivArea'], y = data['SalePrice'])
plt.ylabel('SalePrice', fontsize=13)
plt.xlabel('GrLivArea', fontsize=13)
plt.show()


