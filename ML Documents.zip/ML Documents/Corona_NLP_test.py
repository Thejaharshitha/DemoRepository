#!/usr/bin/env python
# coding: utf-8

# In[16]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as pit
import string
import nltk 
from nltk.corpus import stopwords
nltk.download('stopwords')
import re


# In[19]:


dataset=pd.read_csv('C://Users//892389//OneDrive - Cognizant//Corona_NLP_test.csv')


# In[20]:


# initially displaying the column to be preprocessed
dataset['OriginalTweet'].head()


# In[21]:


# function to remove mentions
def remove_pattern(text,pattern): 
    r=re.findall(pattern, text)
    for i in r:
        text=re.sub(i,'',text)
    return text;


# In[22]:



#print(dataset.shape)


# In[23]:


#calling remove_patterns
dataset['Tweet_tidy']=np.vectorize(remove_pattern)(dataset['OriginalTweet'],"@[\W]*")
#dataset['Tweet_tidy']=np.vectorize(remove_pattern)(dataset['Tweet_tidy'],"#[\W]*")
dataset.head()


# In[24]:


string.punctuation


# In[25]:


# remove punctuations
def remove_punct(text):
    text="".join([char for char in text if char not in string.punctuation])
    text=re.sub('[0-9]+','',text)
    return text


# In[26]:


dataset['Tweet_punct']=dataset['OriginalTweet'].apply(lambda x: remove_punct(x))
#dataset['Tweet_punct']=dataset['OriginalTweet'].str.replace("[^a-zA-Z#]"," ")
dataset.head()


# In[27]:


# function for tokenizantion
def tokenization(text):
    text = re.split('\W+', text)
    return text

dataset['Tweet_tokenized'] = dataset['Tweet_punct'].apply(lambda x: tokenization(x.lower()))
dataset.head()


# In[28]:



stopword = nltk.corpus.stopwords.words('english')


# In[29]:


# function to remove stop words
def remove_stopwords(text):
    text = [word for word in text if word not in stopword]
    return text
    
dataset['Tweet_nonstop'] = dataset['Tweet_tokenized'].apply(lambda x: remove_stopwords(x))
dataset.head()


# In[32]:


#function for stemming
ps = nltk.PorterStemmer()

def stemming(text):
    text = [ps.stem(word) for word in text]
    return text

dataset['Tweet_stemmed'] = dataset['Tweet_nonstop'].apply(lambda x: stemming(x))
dataset.head()


# In[31]:


nltk.download('wordnet')


# In[33]:


#function for lemmatizing
wn = nltk.WordNetLemmatizer()

def lemmatizer(text):
    text = [wn.lemmatize(word) for word in text]
    return text

dataset['Tweet_lemmatized'] = dataset['Tweet_nonstop'].apply(lambda x: lemmatizer(x))
dataset.head()


# In[35]:


output='C://Users//892389//OneDrive - Cognizant//Corona_NLP_test_output.csv'
dataset.to_csv(output, index = False)


# In[ ]:




