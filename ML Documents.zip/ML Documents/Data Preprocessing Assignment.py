#!/usr/bin/env python
# coding: utf-8

# # Importing libraries

# In[75]:


import os
import pandas
import string
import re
import nltk
from nltk.tokenize import word_tokenize


# # Read input file

# In[76]:


filepath=r"C:\Users\606037\OneDrive - Cognizant\Documents\ML\MusicalInstruments_Reviews.csv"
output_path = r"C:\Users\606037\OneDrive - Cognizant\Documents\ML\Output MusicalInstruments_Reviews.csv"
reviews = pandas.read_csv(filepath,usecols=["reviewText"])


# # Funtion to set lowercase and trim blankspace

# In[77]:


def str_format(input_str):
    return input_str.lower().strip()


# # Function to filter all non-word characters

# In[78]:


def remove_punctuation(input_str):
    return re.sub(r'[\W\d]+', ' ',input_str)


# # Function to filter out all pronouns and determiners

# In[79]:


def filter_words(review):
    tokens = nltk.pos_tag(word_tokenize(review), tagset="universal")
    filtered = [word[0] for word in tokens if word[1] not in ("DET","PRON")]
    return " ".join(filtered)


# # Preprocess dataset

# In[ ]:


reviews.dropna(subset=["reviewText"], inplace = True)    # removing null values
reviews['reviewText'] = reviews['reviewText'].apply(lambda text: str_format(text))    # calling str_format function
reviews.drop_duplicates(subset=["reviewText"], keep='first', inplace=True)    # dropping duplicate records
reviews['reviewText'] = reviews[reviews['reviewText'].isin(["null","na"]) == False]    # removing NULL, NA values
reviews['reviewText'] = reviews['reviewText'].apply(lambda text: remove_punctuation(text))    # calling remove_punctuation function
reviews['reviewText'] = reviews['reviewText'].apply(lambda text: filter_words(text))    # calling filter_words function


# # Write output file

# In[ ]:


reviews.to_csv(output_path, index = False)


# In[ ]:




